# typed: strict
# frozen_string_literal: true

require "extend/os/linux/compilers" if OS.linux?

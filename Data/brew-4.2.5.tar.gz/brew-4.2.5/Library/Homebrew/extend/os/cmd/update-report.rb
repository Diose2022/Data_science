# typed: strict
# frozen_string_literal: true

require "extend/os/linux/cmd/update-report" if OS.linux?

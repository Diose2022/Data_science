# typed: strict
# frozen_string_literal: true

require "extend/os/linux/requirements/xcode_requirement" if OS.linux?
